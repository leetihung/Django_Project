from django.shortcuts import render
from app.models import Note
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect
from django.contrib.auth import hashers

def is_login(request):
    return request.session.get('signin', False)
def user_id(request):
    return request.session.get('userid', -1)
def do_login(request, username, password):
    state = check_login(username, password)
    if state['success']:
        # save login info to session
        request.session['signin'] = True
        request.session['userid'] = state['userid']
        request.session['username'] = username

    return state

def check_login(username, password):
    state = {
        'success': True,
        'message': 'none',
        'userid': -1,
    }

    try:
        user = User.objects.get(username=username)

        # to decide password
        if hashers.check_password(password,user.password):
            state['success'] = True
            state['userid'] = user.id
        else:
            # password incorrect
            state['success'] = False
            state['message'] = '密碼不正確'
    except :
        # user not exist
        state['success'] = False
        state['message'] = '使用者不存在'

    return state

def index(request):
    signin = is_login(request)

    try:
        user = User.objects.get(id=user_id(request))
    except:
        uesr = ''

    notes = Note.objects.order_by('-addtime')


    if request.method=="POST":
        if not signin:
            return HttpResponseRedirect('/login.html/')
        else:
            user = User.objects.get(id=user_id(request))
            message = request.POST['message']
            if message !="":
                note = Note(message=message, user=user)
                note.save()
            notes = Note.objects.order_by('-addtime')
            return render(request, 'base.html', locals())
    else:
        return render(request, 'base.html', locals())

def signup(request):
    if request.method=="POST":
        username = request.POST['username']
        password = request.POST['password']
        confirm = request.POST['confirm']
        try:
            User.objects.get(username=username)
            message = '此用戶名已存在'
            return render(request, 'signup.html', locals())
        except:
            if confirm != password:
                message = '兩次密碼輸入必須一致'
                return render(request, 'signup.html', locals())
            elif (username == "") or (password == "") or (confirm == ""):
                message = '表格請勿空白'
                return render(request, 'signup.html', locals())
            else:
                user = User.objects.create_user(username, None, password)
                user.save()
                message = '註冊成功'
                return render(request, 'message.html', locals())
    else:
        message = '註冊帳號'
        return render(request, 'signup.html', locals())

def login(request):
    signin = is_login(request)
    if request.method=="POST":
        username = request.POST['username']
        password = request.POST['password']
        state=do_login(request,username,password)
        if state['success']:
            return HttpResponseRedirect('/')
        else:
            return render(request, 'login.html',locals())
    else:
        state = {'success': False, 'message': '請登入帳號'}
        return render(request,'login.html',locals())

def logout(request):
    request.session['signin'] = False
    request.session['userid'] = -1
    request.session['username'] = ''

    return HttpResponseRedirect('/')




